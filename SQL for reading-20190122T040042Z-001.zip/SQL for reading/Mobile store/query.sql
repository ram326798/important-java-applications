select * from mobile_master;
select * from sales_info;
select * from distributor;
select * from mobile_specification;
select * from customer_info;
select IME_NO, MODEL_NAME from mobile_master where manufacturer = 'Nokia';

select m.IME_NO, m.MODEL_NAME, m.MANUFACTURER, s.CAMERA_QUALITY from mobile_master m
join mobile_specification s on(m.ime_no = s.ime_no) where camera_quality = '5MP';

select model_name, count(model_name) NoOfMobilesSold from sales_info where sales_date = '2012-04-23'
 group by model_name; 

select d.distributor_id, m.model_name, count(model_name) NoOfMobilesSupplied from distributor d
join mobile_master m on(d.distributor_id = m.distributor_id)
 group by m.model_name, m.distributor_id
order by m.distributor_id;

select DISTINCT m.ime_no, m.model_name, m.manufacturer, m.price, s.discount from mobile_master m
join sales_info s 

select d.distributor_name, d.mobile, d.email from distributor d join mobile_master m
on(d.distributor_id = m.distributor_id) where model_name = 'Nokia 1100';

select ime_no, model_name from mobile_master where model_name 
NOT IN( select model_name from sales_info);

select m.ime_no, m.model_name, max(s.net_amount) Net_Amount from mobile_master m
join sales_info s on(m.ime_no = s.ime_no);

select ime_no, model_name, manufacturer, price, price + (price * 10/100) New_Price from mobile_master

select model_name, manufacturer, price from mobile_master where price >= 8500 and price <= 25300 ;

select m.Model_Name, m.Manufacturer, m.Price, m.Warranty_in_Years, s.Internal_mem_in_MB, 
s.Memory_Card_Capacity_GB, s.GPRS, s.Bluetooth, s.Camera_Quality, s.OS from mobile_master m
join mobile_specification s on(m.ime_no = s.ime_no) where m.ime_no = 'MC1000104';

select m.IME_No, m.Model_Name, m.Manufacturer, m.Price, s.GPRS, s.Memory_Card_Capacity_GB
from mobile_master m join mobile_specification s on(m.ime_no = s.ime_no)
where s.GPRS = 'yes' and s.Memory_Card_Capacity_GB >= '16GB';

select c.Customer_Name, s.IME_No, s.Model_Name, s.Sales_Date, s.Net_Amount from customer_info c
join sales_info s on( c.Customer_ID = s.Customer_ID ) group by c.Customer_Name;

select  m.IME_No, m.Model_Name, m.Manufacturer, m.Price, IFNULL(s.Discount, 'NotSold') discount
from mobile_master m left outer
join sales_info s on(m.ime_no = s.ime_no);

select Sales_Date, sum(Net_Amount) TotalNetAmount from sales_info 
where Sales_Date between '2012-04-12' and '2012-04-25' group by sales_date;

select m.IME_No, m.Model_Name, m.Manufacturer, m.Price, s.Battery_Life_Hrs
from mobile_master m join mobile_specification s on( m.ime_no = s.ime_no )
where s.Battery_Life_Hrs = (select max(Battery_Life_Hrs) from mobile_specification);

select IME_No, Model_Name, Manufacturer, Price from mobile_master
where price = (select max(price) from mobile_master);

insert into mobile_master values('MC100', 'Spice', 'China', '2010-04-12', 1, 35350, 'D001');

select c.Customer_ID, c.Customer_Name, c.Address, sum(s.Net_Amount) Total_net_amount
from customer_info c join sales_info s on(c.customer_id = s.customer_id)
group by c.Customer_Name;

select DISTINCT Model_Name, Manufacturer, max(Price) from mobile_master
where Manufacturer = 'Samsung';

select m.IME_No, m.Model_Name, m.Manufacturer, m.Distributor_ID, d.Distributor_Name, m.Price
from mobile_master m join distributor d on( m.distributor_id = d.distributor_id)
where d.Distributor_Name = 'AXA Ltd';

select DISTINCT d.Distributor_ID, d.Distributor_Name, d.Address, d.Mobile, d.Email
from distributor d join mobile_master m on(d.distributor_id = m.distributor_id)
where d.Distributor_ID = (select min(m.Distributor_ID) from mobile_master m
join distributor d on(m.Distributor_ID = d.distributor_id));

insert into sales_info values(1077, '2012-04-20', 'MC1000100', 9500, 2000, 7500, 'C003', 'Nokia C5-03');

select Customer_ID, sum(Net_Amount) from sales_info 
group by Customer_ID;

select DISTINCT d.distributor_id, d.Distributor_Name, d.Address, d.Mobile from distributor d 
join mobile_master m on(d.distributor_id = m.distributor_id)
join mobile_specification s on(m.ime_no = s.ime_no)
where s.Network_3G = 'yes' and os like 'Android%' and camera_quality = '3.5MP';

select DISTINCT m.Model_Name, m.Manufacturer from mobile_master m
join sales_info s on(m.ime_no = s.ime_no) 
group by m.model_name
having m.model_name = (select max(Model_Name) a from sales_info group by );

select s.Model_Name, m.Manufacturer from sales_info s
join mobile_master m on (s.ime_no = m.ime_no) group by s.model_name having count(*) = 
(select max(cnt )from (select count(*) cnt  from sales_info group by model_name)t);

select c.Customer_ID, c.Customer_Name, c.Address from customer_info c
join sales_info s on( c.customer_id = s.customer_id )
group by c.Customer_Name
having sum(net_amount) = 
(select max(s) from (select sum(net_amount) s from sales_info group by customer_id)t);

select m.model_name, m.ime_no, IF(s.discount,'Sold','NotSold') SalesStatus from mobile_master m 
left outer join sales_info s on(m.ime_no = s.ime_no) where m.model_name = 'Samsung GalaxyTAB';


select b.BOOK_CODE, b.BOOK_TITLE, s.SUPPLIER_NAME, max(b.PRICE) PRICE from lms_book_details b
join lms_suppliers_details s on(b.supplier_id = s.supplier_id) group by s.supplier_name;

select * from lms_book_details;

select b.BOOK_CODE, b.BOOK_TITLE, s.SUPPLIER_NAME, max(b.PRICE) PRICE from lms_book_details b
join lms_suppliers_details s on(b.supplier_id = s.supplier_id) group by s.supplier_name, b.BOOK_CODE
order by b.price DESC;

select book_code, BOOK_TITLE, SUPPLIER_NAME, PRICE from lms_book_details o
where price = (select max(price) from lms_book_details where supplier_id = o.supplier_id);