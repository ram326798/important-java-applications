package com.iiht.tests.app;

import java.util.Scanner;

public class AddVowelConsonantCount {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.next();
		String b = sc.next();
		int i, n1 = 0, n2 = 0;
		a = a.toLowerCase();
		b = b.toLowerCase();
		if (a.length() <= 10 && b.length() <= 10) {
			for (i = 0; i < a.length(); i++) {
				if (a.charAt(i) == 'a' || a.charAt(i) == 'e' || a.charAt(i) == 'i' || a.charAt(i) == 'o'
						|| a.charAt(i) == 'u') {
					n1++;
				}
			}
			for (i = 0; i < b.length(); i++) {
				if (b.charAt(i) != 'a' && b.charAt(i) != 'e' && b.charAt(i) != 'i' && b.charAt(i) != 'o'
						&& b.charAt(i) != 'u') {
					n2++;
				}
			}
		} else
			System.out.println("exceeded");
		System.out.println(n1 + n2);
		sc.close();
	}

}
