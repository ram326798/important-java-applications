package com.iiht.pfmock.ui;

import java.util.Scanner;

public class DontStay {

	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int[] a=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		int i=1;
		int count=0;
		for(int j=0;i<=n;j++)
		{
			if(a[j]==i)
			{
				count++;
			}
			i++;
		}
		System.out.println(count);
sc.close();
	}
	
}
