package com.iiht.pfmock.ui;

import java.util.Scanner;

public class ExchangeArrayPositions {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		int k=0;
		int b[]=new int[n];
		for (int index = 0; index < n; index++) {
			k=a[index]-1;
			b[k]=index+1;
		}
		for (int i = 0; i <n; i++) {
			System.out.print(b[i]);
		}
sc.close();
	}

}
