package com.iiht.tests.app;

import java.util.Scanner;

public class Pivot {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int row = sc.nextInt();
		int col = sc.nextInt();
		int a[][] = new int[row][col];
		int i, j;
		for (i = 0; i < row; i++) {
			for (j = 0; j < col; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		int maxValue = a[0][0];
		for (i = 0; i < row; i++) {
			for (j = 0; j < col; j++) {
				if (a[i][j] > maxValue) {
					maxValue = a[i][j];
				}
			}
		}
		System.out.println(maxValue);
		sc.close();
	}

}
