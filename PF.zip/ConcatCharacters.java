package com.iiht.pfmock.ui;

import java.util.Scanner;

public class ConcatCharacters {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		String str[] = new String[n];
		for (int i = 0; i < str.length; i++) {
			str[i] = s.next();
		}
		System.out.println(concatCharacter(str));
		s.close();
	}
	public static String concatCharacter(String a[]) {
		String st="";
		for (int i = 0; i < a.length; i++) {
			st=st+a[i].charAt(a[i].length() - 1);
		}
		return st;
	}
	
}
