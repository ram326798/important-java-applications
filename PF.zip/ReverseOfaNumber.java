package com.iiht.tests.app;

import java.util.Scanner;

public class ReverseOfaNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		int num = sc.nextInt();
		sc.close();
		int temp = num, r, rev = 0;
		while (num != 0) {
			r = num % 10;
			rev = rev * 10 + r;
			num = num / 10;
		}
		System.out.println("reverse of number " + temp + " is " + rev);
	}

}
