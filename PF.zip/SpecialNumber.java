package com.iiht.pfmock.ui;

import java.util.Scanner;

public class SpecialNumber {

	public static void main(String[] args) {
	
		int number,count=0;
		System.out.println("Enter a number");
		Scanner s=new Scanner(System.in);
		number=s.nextInt();
		for(int i=0;i>=0;i++)
		{
			if(i%10==0 || i%10==1 || i%10==2 || i%10==3 || i%10==4 || i%10==5)
			{
				count++;
				if(count==number){
					System.out.println(i);
					break;
				}
			}
			//System.out.println(i);
		}
		
s.close();
	}

}
