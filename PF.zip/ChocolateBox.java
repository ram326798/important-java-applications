  import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        int N = sc.nextInt();
        int a[][]=new int[N][N];
        int i,j;
        for(i=0;i<N;i++){
            for(j=0;j<N;j++){
            a[i][j]=sc.nextInt();
            
        }
    }
    
    int upper_triangle_sum=0;
    int lower_triangle_sum=0;
    for(i=0;i<N;i++){
        for(j=0;j<N;j++){
            if(i<j){
                upper_triangle_sum=upper_triangle_sum+a[i][j];
            }
        }
    }
    
    for(i=0;i<N;i++){
        for(j=0;j<N;j++){
            if(i>j){
                lower_triangle_sum=lower_triangle_sum+a[i][j];
            }
        }
    }
    System.out.println(upper_triangle_sum+" "+lower_triangle_sum);
}
}