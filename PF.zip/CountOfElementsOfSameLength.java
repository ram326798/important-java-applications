package com.iiht.pfmock.ui;

import java.util.Arrays;
import java.util.Scanner;

public class CountOfElementsOfSameLength {

	public static void main(String[] args) {

		int i, count = 0;
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		String str[] = new String[n];
		int k[] = new int[n];
		for (i = 0; i < str.length; i++) {
			str[i] = s.next();
		}
		for (i = 0; i < str.length; i++) {
			k[i] = str[i].length();
		}
		Arrays.sort(k);
		for (i = 0; i < k.length; i++) {
			if (i<k.length-1 && k[i] == k[i + 1]) {
				count++;
				i++;
			}
		}
		System.out.println(count);
		s.close();
	}
}
