package com.iiht.pfmock.ui;

import java.util.Scanner;

public class DeletingTen {

	public static void main(String[] args) {
		int i,j=0,k=0;
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int a[]=new int[n];
		int b[]=new int[n];
		for(i=0;i<n;i++){
			a[i]=s.nextInt();
		}
		for(i=0;i<n;i++){
			if(a[i]!=10)
			{
				b[k]=a[i];
				k++;
			}
		}
		for(j=0;j<n;j++){
			System.out.println(b[j]);
		}
	s.close();
	}
}
