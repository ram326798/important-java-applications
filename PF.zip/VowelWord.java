package com.iiht.pfmock.ui;

import java.util.Scanner;

public class VowelWord {

	public static void main(String[] args) {

		int j, a = 0;
		Scanner s = new Scanner(System.in);
		String str = s.next();
		char c[] = str.toCharArray();
		for (j = 0; j < str.length(); j++) {
			if (c[j] == 'a' || c[j] == 'e' || c[j] == 'i' || c[j] == 'o' || c[j] == 'u') {
				a++;
			}
		}
		//displaying only consonants in a word
		String str2=str.toLowerCase().replaceAll("[aeiou]", "").trim();
		System.out.println(str2);
		//the word contains only vowels
		if (a == c.length) {
			System.out.println("vowel word");
		} else {
			System.out.println("not a vowel word");
		}
		//word contains only 2 vowels
		if (a == 2) {
			System.out.println("valid");
		} else {
			System.out.println("not valid");
		}
		s.close();
	}
}
