package com.iiht.tests.app;
//5

//800 400 200 100 2000
//1600

import java.util.Arrays;
import java.util.Scanner;

public class MobileCharger {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int mob[] = new int[n];
		int i, count = 0;
		for (i = 0; i < mob.length; i++) {
			mob[i] = sc.nextInt();
		}
		int pcc = sc.nextInt();
		Arrays.sort(mob);
		for (i = 0; i < mob.length - 1; i++) {
			if (mob[i] < pcc && pcc > 5 * mob[i]) {
				count++;
				pcc = pcc - (5 * mob[i]);
				mob[i + 1] = mob[i + 1] - mob[i];
				if (pcc == 0) {
					break;
				}
			}
		}
		System.out.println(count);
		sc.close();

	}
}
