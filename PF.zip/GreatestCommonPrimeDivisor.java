package com.iiht.tests.app;

import java.util.Arrays;
import java.util.Scanner;

public class GreatestCommonPrimeDivisor {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		int i, j = 0, count = 0;
		for (i = 2; i < n1 && i < n2; i++) {
			if (n1 % i == 0 && n2 % i == 0) {
				count++;
			}
		}
		int k, primeCount = 0;
		int a[] = new int[count];
		if (count > 0) {
			for (i = 2; i < n1 && i < n2; i++) {
				if (n1 % i == 0 && n2 % i == 0) {
					primeCount = 0;
					for (k = 1; k <= i; k++) {
						if (i % k == 0) {
							primeCount++;
						}
					}
					if (primeCount == 2) {
						a[j] = i;
						j++;
					}

				}
			}
			Arrays.sort(a);
			System.out.println(a[a.length - 1]);
		} else {
			System.out.println("-1");
		}
		sc.close();
	}

}
