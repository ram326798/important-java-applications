package com.iiht.basic.app;

import java.util.Scanner;

public class Pf3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of array");
		int N = sc.nextInt();
		int i, j;
		int a[] = new int[N];
		System.out.println("enter first array elements");
		for (i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		int b[] = new int[N];
		System.out.println("enter second array elements");
		for (j = 0; j < b.length; j++) {
			b[j] = sc.nextInt();
		}
		System.out.println(ChooseMinimum(a, b));
		sc.close();
	}

	public static int ChooseMinimum(int[] a, int[] b) {
		int i, minOfa = a[0], minOfb = b[0], indexa = 0, indexb = 0, nextminOfa = 0, nextminOfb = 0, indexa1 = 0,
				indexb1 = 0;
		for (i = 0; i < a.length; i++) {
			if (a[i] < minOfa) {
				minOfa = a[i];
				indexa = i;
			}
		}
		for (i = 0; i < b.length; i++) {
			if (b[i] < minOfb) {
				minOfb = b[i];
				indexb = i;
			}
		}
		if (indexa != indexb) {
			System.out.println("min in a=" + minOfa + "\nmin in b=" + minOfb);
			return (minOfa + minOfb);
		} else {
			nextminOfa = (indexa + 1) >= a.length ? a[indexa - 1] : a[indexa + 1];
			for (i = 0; i < a.length; i++) {
				if (i != indexa && a[i] < nextminOfa) {
					nextminOfa = a[i];
					indexa1 = i;
				}
			}
			nextminOfb = (indexb + 1) >= b.length ? b[indexb - 1] : b[indexb + 1];
			for (i = 0; i < b.length; i++) {
				if (i != indexb && b[i] < nextminOfb) {
					nextminOfb = b[i];
					indexb1 = i;
				}
			}
			System.out.println("nextmin in a=" + nextminOfa + "\nnextmin in b=" + nextminOfb);
			return Math.min(minOfa + nextminOfb, nextminOfa + minOfb);
		}

	}

}
