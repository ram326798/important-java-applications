import java.util.Scanner;
public class Main 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String str = sc.nextLine();
		String split[] = str.split(",");
		int arr[] = new int[split.length];
		for(int i=0;i<split.length;i++)
		{
			arr[i] = Integer.parseInt(split[i]);
		}
		int min = arr[0];
		int min1 = arr[1]/arr[0];
		boolean flag=false;
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]-arr[i-1] == min)
				flag = true;
			else
			{
				flag = false;
				break;
			}
		}
		if(flag==true)
			System.out.println(arr[arr.length-1]+min);
		else
			System.out.println(arr[arr.length-1]*min1);
		sc.close();
	}
}
