package com.iiht.pfmock.ui;

import java.util.Scanner;

public class SegmentNo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int k;
		for(k=a;k<=b;k++){
			System.out.print(k);
		}
sc.close();
	}

}
