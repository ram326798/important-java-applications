package com.iiht.tests.app;

import java.util.Scanner;

public class DiagonalDifference {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int a[][] = new int[N][N];
		int i, j;
		for (i = 0; i < N; i++) {
			for (j = 0; j < N; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		int d1sum = 0, d2sum = 0, k = N - 1;
		for (i = 0; i < N; i++) {
			for (j = 0; j < N; j++) {
				if (i == j) {
					d1sum += a[i][j];
					d2sum += a[i][k];
					k--;
				}
			}

		}
		System.out.println(d2sum - d1sum);
		sc.close();
	}

}
