package com.iiht.tests.app;

public class ArmstrongNumber {

	public static void main(String[] args) {
		int number = 153;
		int remainder, sum = 0, temp = number;
		while (number != 0) {
			remainder = number % 10;
			sum = sum + (remainder * remainder * remainder);
			number = number / 10;
		}
		if (sum == temp) {
			System.out.println(temp + " is an armstrong number");
		} else
			System.out.println(temp + " is not an armstrong number");
	}

}
