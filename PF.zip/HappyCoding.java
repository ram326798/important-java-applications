import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int lowerlimit = sc.nextInt();
		int upperlimit = sc.nextInt();
		for(int i=1;i<=n;i++)
		{
			if(i%lowerlimit == 0 && i%upperlimit == 0)
				System.out.print("HappyCoding ");
			else if(i%lowerlimit == 0)
				System.out.print("Happy ");
			else if(i%upperlimit==0)
				System.out.print("Coding");
			else
				System.out.print(i+" ");
		}
		sc.close();
	}
}
