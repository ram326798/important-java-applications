package com.iiht.tests.app;

import java.util.Scanner;

public class BoatTravel {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int boatSpeed = sc.nextInt();
		int waterSpeed = sc.nextInt();
		int distance = sc.nextInt();
		int time = distance / (boatSpeed + waterSpeed);
		System.out.println(time);
		sc.close();
	}

}
