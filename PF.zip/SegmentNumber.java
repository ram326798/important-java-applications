package com.iiht.tests.app;

import java.util.Scanner;

public class SegmentNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int l = sc.nextInt();
		int r = sc.nextInt();
		String out = "";
		int output;
		int i;
		if (l > 0 && r > 0) {
			for (i = l; i <= r; i++) {
				out = out + i;
			}
		}
		output = Integer.parseInt(out);
		System.out.println(output);
		sc.close();
	}

}
