package com.iiht.pfmock.ui;

import java.util.Scanner;

public class SubstringOfAWord {

	public static void main(String[] args) {

		int count = 0;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a String");
		String str = s.next();
		System.out.println("Enter a number");
		int num = s.nextInt();
		System.out.println("Enter the length");
		int len = s.nextInt();
		String s1 = "";
		for (int i = num - 1; i < str.length(); i++) {
			if (count != len) {
				s1 = s1 + str.charAt(i);
				count++;
			} else {
				break;
			}

		}
		System.out.println(s1);
		String s2 = "";
		for (int i = s1.length() - 1; i >= 0; --i) {
			s2 = s2 + s1.charAt(i);
		}
		System.out.println(s2);
		if (s1 == s2) {
			System.out.println("palindrome");
		} else {
			System.out.println("not palindrom");
		}
		s.close();
	}

}
