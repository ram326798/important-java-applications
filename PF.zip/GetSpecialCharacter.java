package com.iiht.pfmock.ui;

import java.util.Scanner;

public class GetSpecialCharacter {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter string");
		String str = s.next();
		System.out.println(getSpecialCharacter(str));
		s.close();
	}

	public static String getSpecialCharacter(String str1) {
		String output = "";
		for (int i = 0; i < str1.length(); i++) {
			if (!(str1.charAt(i) >= 65 && str1.charAt(i) <= 90 || str1.charAt(i) >= 97 && str1.charAt(i) <= 122)) {
				output = output + str1.charAt(i);
			}
		}
		return output;
	}

}
