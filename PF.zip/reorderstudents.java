  import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int cn[]=new int[n];
        int index;
        int indexes[]=new int[n];
        int i,j,k,l;
        for(i=0;i<cn.length;i++){
            cn[i]=sc.nextInt();
        }
        for(j=0;j<indexes.length;j++){
            indexes[j]=sc.nextInt();
        }
        int output[]=new int[n];
        for(k=0;k<cn.length;k++){
            index=indexes[k];
            output[index]=cn[k];
        }
        for(l=0;l<output.length;l++){
            System.out.print(output[l]+" ");
        }
    }
}