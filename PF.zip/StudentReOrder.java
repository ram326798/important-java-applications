package com.iiht.pfmock.ui;

import java.util.Scanner;

public class StudentReOrder {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter no of students");
		int noOfStudents = s.nextInt();
		System.out.println("Enter card numbers");
		int card[] = new int[noOfStudents];
		for (int i = 0; i < noOfStudents; i++) {
			card[i] = s.nextInt();
		}
		int index;
		System.out.println("Enter order numbers");
		int order[] = new int[noOfStudents];
		for (int i = 0; i < noOfStudents; i++) {
			order[i] = s.nextInt();
		}
		int output[] = new int[noOfStudents];
		for (int k = 0; k < noOfStudents; k++) {
			index = order[k];
			output[index] = card[k];
		}
		for (int i = 0; i < noOfStudents; i++) {
			System.out.println(output[i]);
		}
		s.close();
	}

}
