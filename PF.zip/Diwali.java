package com.iiht.tests.app;

import java.util.Scanner;

public class Diwali {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if (n < 3) {
			n = n + 4;
		} else if (n >= 3 && n <= 5) {
			n = n + 6;
		} else {
			n = 12;
		}
		System.out.println(n);
		sc.close();
	}

}
