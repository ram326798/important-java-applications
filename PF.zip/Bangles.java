package com.iiht.pfmock.ui;

import java.util.Scanner;

public class Bangles {

	public static void main(String[] args) {
		
		double x1,x2,y1,y2,r1,r2;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter x1,y1 values");
		x1=s.nextInt();
		y1=s.nextInt();
		System.out.println("Enter x2,y2 values");
		x2=s.nextInt();
		y2=s.nextInt();
		System.out.println("Enter r1,r2 values");
		r1=s.nextInt();
		r2=s.nextInt();
		double d=Math.sqrt(Math.pow(x2-x1, 2)+Math.pow(y2-y1, 2));
		if(r1+r2>d){
			System.out.println("Intersect");
			System.out.printf("%1.2f",d);
		}
		else if(r1+r2<d)
		{
			System.out.println("Do not touch");
			System.out.printf("%1.2f",d);
		}
		else {
			System.err.println("Touch");
			System.out.printf("%1.2f",d);
		}
		s.close();
	}

}
