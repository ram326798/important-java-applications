package com.iiht.pfmock.ui;

import java.util.Arrays;
import java.util.Scanner;

public class DuplicateElements {

	public static void main(String[] args) {

		int j = 0, l, sum = 0;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter size");
		int n = s.nextInt();
		int count = 1;
		int a[] = new int[n];

		System.out.println("Enter the elements");
		for (int i = 0; i < n; i++) {
			a[i] = s.nextInt();
		}
		Arrays.sort(a);
		for (int i = 0; i < n - 1; i++) {
			if (a[i] != a[i + 1]) {
				count++;
			}
		}
		int b[] = new int[count];

		for (int i = 0; i < n - 1; i++) {
			if (a[i] != a[i + 1]) {
				b[j] = a[i];
				j++;
			}
		}
		b[j] = a[n - 1];
		for (int i = 0; i < b.length; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();
		for (l = 0; l < b.length; l++) {
			if (b[l] % 2 == 0) {
				sum = sum + b[l];
			}
		}
		System.out.println(sum);

		s.close();
	}

}
