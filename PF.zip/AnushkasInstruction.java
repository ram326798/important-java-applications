package com.iiht.tests.app;

import java.util.Scanner;

//count the occurence of same character and display count with character
//example input=aabbcc, output=a2b2c2
public class AnushkasInstruction {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		int i, j, count;
		char c = 0;
		for (i = 0; i <= s.length() - 1; i++) {
			count = 1;
			c = s.charAt(i);
			for (j = i + 1; j < s.length(); j++) {
				if (s.charAt(i) == s.charAt(j)) {
					count++;
					c = s.charAt(i);
				} else
					break;
			}
			if (count >= 1) {
				System.out.print(c + "" + count);
			}

			i = i + count - 1;
		}
		sc.close();
	}

}
