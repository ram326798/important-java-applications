package com.iiht.pfmock.ui;

import java.util.Scanner;

public class SkewSymmentric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int s = sc.nextInt();
		int[][] mat = new int[s][s];
		int[][] trmat = new int[s][s];
		int[][] negTrMat = new int[s][s];
		int i = 0;
		int j = 0;

		for (i = 0; i < s; i++)
			for (j = 0; j < s; j++) {
				mat[i][j] = sc.nextInt();
			}
		for (i = 0; i < s; i++) {
			for (j = 0; j < s; j++) {
				System.out.print(mat[i][j] + " ");
			}
			System.out.println(" ");
		}
		for (i = 0; i < s; i++) {
			for (j = 0; j < s; j++) {
				trmat[i][j] = mat[j][i];
			}

		}
		for (i = 0; i < s; i++) {
			for (j = 0; j < s; j++) {
				negTrMat[i][j] = -1 * trmat[i][j];
			}

		}

		for (i = 0; i < s; i++) {
			for (j = 0; j < s; j++) {
				if (negTrMat[i][j] == mat[i][j])
					continue;
				else {

					break;
				}

			}

		}
		if ((i == s) & (j == s)) {
			System.out.println("true");
			for (i = 0; i < s; i++) {
				for (j = 0; j < s; j++) {
					System.out.print(mat[i][j] - trmat[i][j] + " ");
				}
				System.out.println(" ");

			}

		} else {
			System.out.println("false");

			for (i = 0; i < s; i++) {
				for (j = 0; j < s; j++) {
					System.out.print(trmat[i][j]);
				}
				System.out.println(" ");

			}

		}
sc.close();
	}
}
