package com.iiht.tests.app;

import java.util.Scanner;

public class BiggerNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i, remainder, count = 0;
		while (n != 0) {
			remainder = n % 10;
			for (i = remainder + 1; i <= 9; i++) {
				count++;
			}
			n = n / 10;
		}
		System.out.println(count);
		sc.close();
	}

}
