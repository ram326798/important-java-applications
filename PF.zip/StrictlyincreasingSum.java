import java.util.Scanner;
public class Main 
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.println(maxSum(arr,n));
		sc.close();
	}
	static int maxSum(int arr[],int n)
	{
		int max_sum=0;
		int current_sum = arr[0];
		for(int i=1;i<n;i++)
		{
			if(arr[i-1]<arr[i])
				current_sum = current_sum + arr[i];
			else
			{
				max_sum = Math.max(max_sum, current_sum);
				current_sum = arr[i];
			}
		}
		return Math.max(max_sum, current_sum);
	}
}
