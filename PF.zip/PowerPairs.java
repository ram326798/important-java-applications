package com.iiht.tests.app;

import java.util.Scanner;

public class PowerPairs {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		int a[] = new int[size];
		int i, j;
		for (i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		int count = 0;
		for (j = a.length - 1; j >= 0; j--) {
			for (i = 0; i < j; i++) {
				if (a[j] % a[i] == 0) {
					//power pairs
					//System.out.print("("+a[i]+","+a[j]+") ");
					count++;
				}
			}
		}
		System.out.println(count);
		sc.close();
	}

}
