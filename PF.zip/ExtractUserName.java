package com.iiht.pfmock.ui;

import java.util.Scanner;

public class ExtractUserName {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter email");
		String email = s.next();
		String str = "";
		int count = 0;
		for (int i = 0; i < email.length(); i++) {
			if (email.charAt(i) != '@') {
				count++;
			}
		}
		if (count == email.length()) {
			System.out.println("Enter valid email");
		} else if (email.charAt(0) == '@') {
			System.out.println("Enter valid email");
		} else {
			int i = email.indexOf('@');
			for (int i1 = 0; i1 < i; i1++) {
				str = str + email.charAt(i1);
			}
			System.out.print(str);
		}

		s.close();
	}
}
