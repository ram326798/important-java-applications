package com.iiht.tests.app;

import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter table to be printed");
		int num = sc.nextInt();
		sc.close();
		int i, res;
		for (i = 1; i <= 10; i++) {
			res = num * i;
			System.out.println(num + " x " + i + " = " + res);

		}
	}

}
