package com.iiht.tests.app;

import java.util.Scanner;

public class ExchangePositionsInArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int size = sc.nextInt();
		int a[] = new int[size];
		int i;
		for (i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		int max = a[0];
		for (i = 0; i < a.length; i++) {
			if (a[i] > max) {
				max = a[i];
			}
		}
		System.out.println(max);
		int index = 0;
		int b[] = new int[max];
		for (i = 0; i < a.length; i++) {
			index = a[i] - 1;
			b[index] = i + 1;
		}
		for (i = 0; i < b.length; i++) {
			System.out.print(b[i] + " ");
		}
		sc.close();

	}

}
