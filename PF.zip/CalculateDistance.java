package com.iiht.pfmock.ui;

import java.util.Scanner;

public class CalculateDistance {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter x1,y1,x2,y2 values");
		int x1 = s.nextInt();
		int y1 = s.nextInt();
		int x2 = s.nextInt();
		int y2 = s.nextInt();
		System.out.println(distance(x1, x2, y1, y2));
		s.close();
	}

	public static double distance(int x1, int x2, int y1, int y2) {
		double d = Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
		return Math.round(d);
	}

}
