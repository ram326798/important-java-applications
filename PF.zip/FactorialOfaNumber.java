package com.iiht.tests.app;

import java.util.Scanner;

public class FactorialOfaNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		int num = sc.nextInt();
		sc.close();
		int fact = 1, i;
		for (i = 2; i <= num; i++) {
			fact = fact * i;
		}
		System.out.println(num + "! = " + fact);
	}

}
