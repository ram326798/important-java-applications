  import java.util.*;
class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int M,N;
        M=sc.nextInt();
        N=sc.nextInt();
        int i,j,c=0,check;
        for(i=M;i<=N;i++){
            check=0;
            String s=Integer.toString(i);
            for(j=0;j<s.length()-1;j++){
                if((s.charAt(j)+1 ==s.charAt(j+1)) || (s.charAt(j)-1 ==s.charAt(j+1))){
                    check++;
                    if(check==s.length()-1){
                        //System.out.println(s);
                        c++;
                    }
                }
            }
        }
        
        System.out.println(c);
    }
}