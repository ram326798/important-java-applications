package com.iiht.tests.app;

import java.util.Scanner;

public class ShareAnApple {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int b = sc.nextInt();
		int applesWitha = a - 1;
		int applesWithb = b + 1;
		boolean flag = false;
		if (applesWitha == applesWithb) {
			flag = true;
			System.out.println(flag);
			System.out.println(applesWitha);
		} else {
			System.out.println(flag);
			System.out.println(Math.abs(a - b));
		}
		sc.close();
	}

}
