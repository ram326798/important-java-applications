  import java.util.*;
class Main{
    public static void main(String[] args){
        int N;
        Scanner sc=new Scanner(System.in);
        N=sc.nextInt();
        int i;
        int count=0;
        int rem;
        for(i=0;i<=i;i++){
            rem=i%10;
            if(rem==0 || rem==1 || rem==2 || rem==3 || rem==4 || rem==5){
                count =count+1;
            
            }
            if(count==N){
                System.out.println(i);
                break;
            }
            
        }
    }
}
             

