import java.util.Scanner;

public class Main2 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int max = sc.nextInt();
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i] = sc.nextInt();
		}
		for(int i=1;i<=max;i++)
		{
			boolean flag = false;
			int quotient = i;
			while(quotient>0)
			{
				boolean flag1 = false;
				int rem = quotient%10;
				for(int k=0;k<arr.length;k++)
				{
					if(rem==arr[k])
					{
						flag1=true;
					}
				}
				if(flag1)
				{
					flag=true;
					quotient = quotient / 10;
				}
				else
				{
					flag = false;
					break;
				}
			}
			if(flag)
				System.out.print(i+" ");
		}
		sc.close();
	}
}