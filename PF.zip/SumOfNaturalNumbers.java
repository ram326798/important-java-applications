package com.iiht.tests.app;

import java.util.Scanner;

public class SumOfNaturalNumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter range");
		int n = sc.nextInt();
		sc.close();
		int sum = 0, i;
		for (i = 1; i <= n; i++) {
			sum = sum + i;
		}
		System.out.println("sum of " + n + " natural numbers is " + sum);

	}

}
