package com.iiht.tests.app;

import java.util.Scanner;

public class ReverseOfAElementInArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of array");
		int l = sc.nextInt();
		int i;
		int a[] = new int[l];
		System.out.println("enter array elements");
		for (i = 0; i < a.length; i++) {
			a[i] = sc.nextInt();
		}
		System.out.println("enter index to be compared with");
		int index = sc.nextInt();
		int sum = 0, rev = 0, r;
		for (i = 0; i < a.length; i++) {
			if (a[index] < a[i]) {
				sum = sum + a[i];
			}
		}
		System.out.println(sum);
		int temp = sum;
		while (temp != 0) {
			r = temp % 10;
			rev = rev * 10 + r;
			temp /= 10;
		}
		System.out.println(rev);
		sc.close();
	}

}
