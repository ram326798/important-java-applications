package com.iiht.pfmock.ui;

import java.util.Scanner;

public class FormNewWord {
	public static String formNewWord(String a,int m){
	String str1 = "";
	String str2 = "";
	for (int i = 0; i < m; i++) {
		str1 = str1 + a.charAt(i);
	}
	for (int i = a.length() - m; i <= a.length() - 1; i++) {
		str2 = str2 + a.charAt(i);
	}
	String str3=str1 + str2;
	return str3; 
	}
	    
	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter a string");
		String str = s.next();
		System.out.println("Enter a value");
		int n = s.nextInt();
		if (str.length()%2==0) {
			System.out.println(formNewWord( str, n));
		}
		else{
			System.out.println("length is odd");
		}
		s.close();
		 
	}
	
}
