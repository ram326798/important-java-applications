package com.iiht.pfmock.ui;

import java.util.Scanner;

public class SumOfIntegers {

	public static void main(String[] args) {

		//sum of integers : i/p=abds123nkn5 o/p=11
		int i, sum = 0;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a string");
		String str = s.nextLine();
		for (i = 0; i < str.length(); i++) {
			if (Character.isDigit(str.charAt(i))) {
				sum = sum + Integer.parseInt(str.charAt(i) + "");
			}
		}
		System.out.println(sum);
		if (sum == 0) {
			System.out.println(-1);
		}
		s.close();
	}

}
