  import java.util.*;
class Main{
public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int x1=sc.nextInt();
        int y1=sc.nextInt();
        int x2=sc.nextInt();
        int y2=sc.nextInt();
        int R1=sc.nextInt();
        int R2=sc.nextInt();
        float a=(float) Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
        if(R1+R2 >a){
            System.out.println("Intersects");
        }
        else if(R1+R2<a){
            System.out.println("Do not Touch");
        }
        else{
            System.out.println("Touches");
        }
        System.out.println(String.format("%1.2f",a));
    }
}