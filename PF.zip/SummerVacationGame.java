package com.iiht.tests.app;

import java.util.Scanner;

//ARRANGE DIGITS OF NUMBER IN INCREMENTAL ORDER FROM RIGHT--->LEFT
public class SummerVacationGame {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int r;
		String nums = Integer.toString(num);
		int i,temp;
		for(i=0;i<nums.length()-1;i++){
			if(nums.charAt(i)<nums.charAt(i+1)){
				temp=nums.charAt(i);
							
			}
		}
	}

}
