package com.iiht.pfmock.ui;

import java.util.Scanner;

public class GetNoOfDays {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter year");
		int year = s.nextInt();
		System.out.println("Enter month");
		int month = s.nextInt();
		int result = getNoOfDays(year, month);
		System.out.println("Days : " + result);
		s.close();
	}

	private static int getNoOfDays(int year, int month) {
		if (month == 0 || month == 2 || month == 4 || month == 6 || month == 7 || month == 9 || month == 11) {
			return 31;
		} else if (month == 1) {
			if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) {
				return 29;
			} else {
				return 28;
			}
		} else {
			return 30;
		}
	}

}
