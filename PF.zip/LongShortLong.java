package com.iiht.pfmock.ui;

import java.util.Scanner;

public class LongShortLong {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		String str = s.next();
		String str2 = s.next();
		//print the word with highest length
		if (str.length() > str2.length()) {
			System.out.println(str + str2 + str);
		} else {
			System.out.println(str2 + str + str2);
		}
		s.close();
	}

}
