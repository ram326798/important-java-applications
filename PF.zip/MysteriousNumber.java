import java.util.Scanner;
public class MysteriousNumber 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int n = Integer.parseInt(sc.nextLine());
		int count=0;
		int i = 1;
		while(n>0)
		{
			if(!findFibonacci(i) && !findPrime(i))
			{
				count++;
			}
			if(n==count)
			{
				System.out.println(i);
				break;
			}
			i++;
		}
		sc.close();
	}
	static boolean findFibonacci(int n)
	{
		int a = 0, b=1;
		int c;
		boolean flag = false;
		for(int i=0;i<n;i++)
		{
			c = a + b;
			if(n==c)
			{
				flag = true;
				break;
			}
			a = b;
			b = c;
		}
		return flag;
	}
	static boolean findPrime(int n)
	{
		if(n%2==0 || n<2)
		{
			return false;
		}
		int x = (int) Math.sqrt(n);
		for(int i=3;i<=x;i++)
		{
			if(n%i==0)
				return false;
		}
		return true;
	}
}