package com.iiht.pfmock.ui;

import java.util.Scanner;

public class ReturnMonthName {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the date in the format of dd-mm-yyyy");
		String s1 = sc.next();
		int i = 0;


		String s = "";
		for (i = 3; i <= 4; i++) {

			s = s + s1.charAt(i);

		}

		switch (s) {
		case "01":
			System.out.println("january");
			break;
		case "02":
			System.out.println("febuary");
			break;
		case "03":
			System.out.println("march");
			break;
		case "04":
			System.out.println("April");
			break;
		case "05":
			System.out.println("May");
			break;
		case "06":
			System.out.println("June");
			break;
		case "07":
			System.out.println("July");
			break;
		case "08":
			System.out.println("August");
			break;
		case "09":
			System.out.println("September");
			break;
		case "10":
			System.out.println("October");
			break;
		case "11":
			System.out.println("November");
			break;
		case "12":
			System.out.println("December");
			break;
		default:
			System.out.println("invalid month");

		}
		sc.close();
	}
}