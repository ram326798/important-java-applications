/*Simple Questions:
Problem # 1:
Write a query to display the member id, member name, city and membership status who are 
all having life time membership. Hint: Life time membership status is “Permanent”.*/
select member_id,member_name,city,membership_status from lms_members
where membership_status='Permanent';

/*Problem # 2:
Write a query to display the book code, publication, price and supplier name of the book witch 
is taken frequently.*/

select lbd.book_code,lbd.publication,lbd.price,lsd.supplier_name 
from lms_book_details lbd
inner join 
lms_suppliers_details lsd
on lbd.supplier_id=lsd.supplier_id
where lbd.book_code in
(select bc from
    (
        SELECT book_code bc, COUNT(book_code)   
        FROM lms_book_issue 
        GROUP BY book_code   
        HAVING COUNT(book_code)=
        (   
            SELECT max(mycount) FROM 
            (   
                SELECT COUNT(book_code) mycount   
                FROM lms_book_issue    
                GROUP BY book_code
            ) c
        )
    ) c1
);
/*Problem # 3:
Write a query to display the member id, member name who have taken the book with book code 
'BL000002'. */
select lm.member_id,lm.member_name
from lms_members lm
inner join
lms_book_issue lbi
on lm.member_id=lbi.member_id
where book_code='BL000002';

/*Problem # 4:
Write a query to display the book code, book title and author of the books whose author 
name begins with 'P'.*/
select book_code,book_title,author
from lms_book_details
where author like 'P%';

/*Problem # 5:
Write a query to display the total number of Java books available in library with alias name 
‘NO_OF_BOOKS’. */
select  count(*) NO_OF_BOOKS from lms_book_details
where category='JAVA';

/*Problem # 6:
Write a query to list the category and number of books in each category with alias name 
‘NO_OF_BOOKS’.*/

select category,count(category)
from lms_book_details
group by category;

/*Problem # 7:
Write a query to display the number of books published by "Prentice Hall” with the alias 
name “NO_OF_BOOKS”.*/

select count(*) NO_OF_BOOKS from lms_book_details
where publication='Prentice Hall';

/*Problem # 8:
Write a query to display the book code, book title of the books which are issued on the 
date "1st April 2012".*/
select lbd.book_code,lbd.book_title
from 
lms_book_details lbd
inner join
lms_book_issue lbi
on lbd.book_code=lbi.book_code
where date_issue='2012-04-01';

/*Problem # 9:
Write a query to display the member id, member name, date of registration and expiry date 
of the members whose membership expiry date is before APR 2013.*/
select member_id,member_name,date_register,date_expire
from lms_members
where  date_format(date_expire,'%m %Y')<'04 2013';

/*Problem # 10:
write a query to display the member id, member name, date of registration, membership status of 
the members who registered before  "March 2012" and membership status is "Temporary" */
select member_id,member_name,date_register,membership_status
from lms_members
where  date_format(date_expire,'%m %Y')<'03 2013'
and
membership_status='Temporary';

/*Problem #11:
Write a query to display the member id, member name who’s City is CHENNAI or DELHI.
Hint: Display the member name in title case with alias name 'Name'. */
select member_id,member_name
from lms_members
where city in('CHENNAI','DELHI');

/*Problem #12:
Write a query to concatenate book title, author and display in the following format.
Book_Title_is_written_by_Author
Example:  Let Us C_is_written_by_Yashavant Kanetkar
Hint: display unique books. Use “BOOK_WRITTEN_BY” as alias name. */

select distinct(concat(book_title,'_is_written_by_',author)) BOOK_WRITTEN_BY
from lms_book_details;

/*Problem #13:
Write a query to display the average price of books which is belonging to ‘JAVA’ 
category with alias name “AVERAGEPRICE”.*/
SELECT avg(price) AVERAGEPRICE FROM lms_book_details
where category='JAVA';


/*Problem #14:
Write a query to display the supplier id, supplier name and email of the suppliers 
who are all having gmail account.*/
select supplier_id,supplier_name,email
from lms_suppliers_details
where email like '%gmail%';

/*Problem#15:
Write a query to display the supplier id, supplier name and contact details. 
Contact details can be either phone number or email or address with alias name 
“CONTACTDETAILS”. If phone number is null then display email, even if email also null 
then display the address of the supplier. Hint: Use Coalesce function. */
select supplier_id,supplier_name,coalesce(cast(contact as char(10)),email,address) 
CONTACTDETAILS
from lms_suppliers_details;
select * from lms_suppliers_details;
/*Problem#16:
Write a query to display the supplier id, supplier name and contact.  
If phone number is null then display ‘No’ else display ‘Yes’ with alias name “PHONENUMAVAILABLE”. 
Hint: Use ISNULL.
*/
select supplier_id,supplier_name,contact,IF(contact=null,'No','Yes') PHONENUMAVAILABLE
from lms_suppliers_details;

/*Problem#17:
Write a query to display the member id, member name, city and member status of members
with the total fine paid by them with alias name “Fine”.*/
select lm.member_id,lm.member_name,city,lm.membership_status,
sum(fine_amount) 'Fine'
from lms_members lm
inner join
lms_book_issue lbi
on lm.member_id=lbi.member_id
inner join
lms_fine_details lfd
on lbi.fine_range=lfd.fine_range
group by lm.member_id;