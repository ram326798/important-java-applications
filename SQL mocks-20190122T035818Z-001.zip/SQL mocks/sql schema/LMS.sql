create database db_lms;
use db_lms;
create table LMS_MEMBERS
(
MEMBER_ID VARCHAR(10),
MEMBER_NAME VARCHAR(30),
CITY  VARCHAR(30),
DATE_REGISTER DATE,
DATE_EXPIRE DATE,
MEMBERSHIP_STATUS VARCHAR(15),
CONSTRAINT PK1 PRIMARY KEY(MEMBER_ID)
);
CREATE TABLE LMS_SUPPLIERS_DETAILS
(
SUPPLIER_ID VARCHAR(3),
SUPPLIER_NAME VARCHAR(30),
ADDRESSES VARCHAR(50),
CONTACT NVARCHAR(15),
EMAIL NVARCHAR(15),
CONSTRAINT PK4 PRIMARY KEY(SUPPLIER_ID)
);
create table LMS_BOOK_ISSUE
(
BOOK_ISSUE_NO int,
MEMBER_ID varchar(10),
BOOK_CODE varchar(10),
DATE_ISSUE date,
DATE_RETURN date,
DATE_RETURNED date,
BOOK_ISSUE_STATUS varchar(20),
FINE_RANGE varchar(3),
constraint pk2 primary key (BOOK_ISSUE_NO)
); 
create table LMS_BOOK_DETAILS
(
BOOK_CODE varchar(10),
BOOK_TITLE varchar(50),
CATEGORY varchar(15),
AUTHOR varchar(30),
PUBLICATION varchar(30),
PUBLISH_DATE date,
BOOK_EDITION int,
PRICE float,
RACK_NUM varchar(3),
DATE_ARRIVAL date,
SUPPLIER_ID varchar(3),
constraint pk3 primary key (BOOK_CODE)
);
CREATE TABLE LMS_FINE_DETAILS
(
FINE_RANGE VARCHAR(3),
FINE_AMOUNT INT,
CONSTRAINT PK5 PRIMARY KEY(FINE_RANGE)
);

ALTER TABLE LMS_BOOK_ISSUE ADD CONSTRAINT FK1 FOREIGN KEY(MEMBER_ID) REFERENCES LMS_MEMBERS(MEMBER_ID);
ALTER TABLE LMS_BOOK_ISSUE ADD CONSTRAINT FK2 FOREIGN KEY(BOOK_CODE) REFERENCES LMS_BOOK_DETAILS(BOOK_CODE);
ALTER TABLE LMS_BOOK_ISSUE ADD CONSTRAINT FK3 FOREIGN KEY(FINE_RANGE) REFERENCES LMS_FINE_DETAILS(FINE_RANGE);
 ALTER TABLE LMS_BOOK_DETAILS ADD CONSTRAINT FK4 FOREIGN KEY(SUPPLIER_ID) REFERENCES LMS_SUPPLIERS_DETAILS(SUPPLIER_ID);

Insert into LMS_MEMBERS Values('LM001', 'AMIT', 'CHENNAI', '2012-02-12', '2013-02-11','Temporary');
Insert into LMS_MEMBERS Values('LM002', 'ABDHUL', 'DELHI', '2012-04-10', '2013-04-09','Temporary');
Insert into LMS_MEMBERS Values('LM003', 'GAYAN', 'CHENNAI', '2013-05-12','2013-12-23', 'Permanent');
Insert into LMS_MEMBERS Values('LM004', 'RADHA', 'CHENNAI', '2012-04-13', '2013-09-12', 'Temporary');
Insert into LMS_MEMBERS Values('LM006', 'MOHAN', 'CHENNAI', '2012-04-12', '2013-12-12','Temporary');

Insert into  LMS_SUPPLIERS_DETAILS Values ('S01','SINGAPORE SHOPPEE', 'CHENNAI', 9894123555,'sing@gmail.com');
Insert into  LMS_SUPPLIERS_DETAILS Values ('S02','JK Stores', 'MUMBAI', 9940123450 ,'jks@yahoo.com');
Insert into  LMS_SUPPLIERS_DETAILS Values ('S03','ROSE BOOK STORE', 'TRIVANDRUM', 9444411222,'rose@gmail.com');
Insert into  LMS_SUPPLIERS_DETAILS Values ('S04','KAVARI STORE', 'DELHI', 8630001452,'kavi@redif.com');
Insert into  LMS_SUPPLIERS_DETAILS Values ('S05','EINSTEN BOOK GALLARY', 'US', 9542000001,'eingal@aol.com');
Insert into  LMS_SUPPLIERS_DETAILS Values ('S06','AKBAR STORE', 'MUMBAI',7855623100 ,'akbakst@aol.com');

Insert into LMS_BOOK_DETAILS Values('BL000001', 'Java How To Do Program', 'JAVA', 'Paul J. Deitel', 'Prentice Hall', '1999-12-10', 6, 600.00, 'A1', '2011-05-10', 'S01');
Insert into LMS_BOOK_DETAILS Values('BL000002', 'Java: The Complete Reference ', 'JAVA', 'Herbert Schildt',  'Tata Mcgraw Hill ', '2011-10-10', 5, 750.00, 'A1', '2011-05-10', 'S03');
Insert into LMS_BOOK_DETAILS Values('BL000003', 'Java How To Do Program', 'JAVA', 'Paul J. Deitel', 'Prentice Hall', '1999-12-10', 6, 600.00, 'A1', '2012-05-12', 'S01');
Insert into LMS_BOOK_DETAILS Values('BL000004', 'Java: The Complete Reference ', 'JAVA', 'Herbert Schildt', 'Tata Mcgraw Hill ', '2011-10-10', 5, 750.00, 'A1', '2012-05-12', 'S01');
Insert into LMS_BOOK_DETAILS Values('BL000005', 'Java How To Do Program', 'JAVA', 'Paul J. Deitel',  'Prentice Hall', '1999-12-10', 6, 600.00, 'A1', '2012-05-12', 'S01');
Insert into LMS_BOOK_DETAILS Values('BL000006', 'Java: The Complete Reference ', 'JAVA', 'Herbert Schildt', 'Tata Mcgraw Hill ', '2011-10-10', 5, 750.00, 'A1', '2012-05-12', 'S03');
Insert into LMS_BOOK_DETAILS Values('BL000007', 'Let Us C', 'C', 'Yashavant Kanetkar ', 'BPB Publications', '2010-12-11',  9, 500.00 , 'A3', '2010-01-03', 'S03');
Insert into LMS_BOOK_DETAILS Values('BL000008', 'Let Us C', 'C', 'Yashavant Kanetkar ','BPB Publications', '2010-12-11',  9, 500.00 , 'A3', '2010-01-03', 'S04');

Insert into LMS_FINE_DETAILS Values('R1', 20);
insert into LMS_FINE_DETAILS Values('R2', 50);
Insert into LMS_FINE_DETAILS Values('R3', 75);
Insert into LMS_FINE_DETAILS Values('R4', 100);
Insert into LMS_FINE_DETAILS Values('R5', 150);
Insert into LMS_FINE_DETAILS Values('R6', 200);

Insert into LMS_BOOK_ISSUE Values (001, 'LM001', 'BL000001', '2012-05-05', '2012-05-03', '2012-04-12','N', 'R1');
Insert into LMS_BOOK_ISSUE Values (002, 'LM002', 'BL000002', '2012-03-04', '2012-06-05','2012-04-05', 'N', 'R2');
Insert into LMS_BOOK_ISSUE Values (003, 'LM003', 'BL000007', '2012-01-04', '2012-06-04', '2012-02-04','Y','R1');
Insert into LMS_BOOK_ISSUE Values (004, 'LM004', 'BL000005', '2012-01-04', '2012-06-04','2012-02-04', 'Y', 'R1');
Insert into LMS_BOOK_ISSUE Values (005, 'LM006', 'BL000008', '2012-03-03', '2012-12-04','2012-04-04','N', 'R2');

select * from lms_members;
select * from lms_book_issue;
select * from lms_book_details;
select * from lms_fine_details;
select * from lms_suppliers_details;

/**Simple queries**/

select member_id,member_name,city,membership_status from lms_members where membership_status='permanent';
select a.book_code,b.publication,b.price,c.supplier_name, count(a.book_code)from lms_book_issue a join lms_book_details b join lms_suppliers_details c  on a.book_code=b.book_code and b.supplier_id=c.supplier_id group by a.book_code having count(a.book_code)=(select count(book_code) from lms_book_details a group by book_code order by count(book_code) desc limit 1);
select m.member_id,m.member_name from lms_members m join lms_book_issue i on m.member_id=i.member_id and book_code='BL000002';
select book_code,book_title,author from lms_book_details where author like 'P%';
select count(book_code) as 'no_of_books' from lms_book_details where category='java';
select book_title,count(book_code)as 'no of books' from lms_book_details group by category;
select count(book_code) as'no_of_books' from lms_book_details where publication='Prentice Hall';
select i.book_code,d.book_title from lms_book_issue i join lms_book_details d on d.book_code=i.book_code and date_issue='2012-04-01';
select member_id,member_name,date_register,date_expire from lms_members where date_expire<'2013-04-01';;
select member_id,member_name,date_register,membership_status from lms_members where date_register<'2012-03-01' and membership_status='temporary';
select member_id, concat(upper(substr(member_name,1,1)),lower(substr(member_name,2))) as'name'from lms_members where city='chennai' or city= 'delhi';
select concat(book_title," _written by_ ",author) as'BOOK_WRITTEN_BY' from lms_book_details;
select avg(price)as 'Average_Price'from lms_book_details where category='java';
select supplier_id,supplier_name from lms_suppliers_details where email like '%@gmail%';
select supplier_id,supplier_name,coalesce(contact,email,addresses) as 'CONTACT DEATAILS'from lms_suppliers_details;
select supplier_id,supplier_name,if(contact is null,"no","yes") as'PHONENUMBERAVAILABLE' from lms_suppliers_details;
select m.member_id,m.member_name,m.city,m.membership_status,sum(f.fine_amount)from lms_members m  join lms_fine_details f join lms_book_issue i on m.member_id=i.member_id and i.fine_range=f.fine_range group by i.member_id;   

 
/**Average**/

select m.member_id,m.member_name,b.book_code,b.book_title from lms_members m join lms_book_details b join lms_book_issue i on m.member_id=i.member_id and b.book_code=i.book_code;
select count(b.book_code) from lms_book_details b where b.book_code not in(select book_code from lms_book_issue);
select m.member_id,m.member_name,f.fine_range,f.fine_amount from lms_members m join lms_fine_details f join lms_book_issue i on m.member_id=i.member_id and i.fine_range=f.fine_range group by i.member_id having sum(f.fine_amount)<100;
select book_code,BOOK_TITLE,PUBLICATION,BOOK_EDITION from lms_book_details order by PUBLISH_DATE,PUBLICATION,BOOK_EDITION; 

